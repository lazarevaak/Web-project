from django.db import models

class Article(models.Model):
    title = models.CharField(verbose_name="Название", max_length=250)
    theme = models.CharField(verbose_name="Тема", max_length=250)
    text = models.TextField(verbose_name="Текст")

