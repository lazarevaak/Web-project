from django.shortcuts import render
from .models import *
# Create your views here.

def Home(request):
    return render(request, 'base.html')

def Arts(request):
    arts = Article.objects.all()
    return render(request, 'articles.html', {'arts': arts})